<?php
// src/Entity/Reservation.php

namespace App\Entity;

use App\Repository\ReservationRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ReservationRepository::class)]
class Reservation
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id_res = null;

    #[ORM\Column(length: 255)]
    private ?string $nom_client = null;

    #[ORM\Column]
    private ?int $qte_res = null;

    #[ORM\Column(type: 'date')]
    private ?\DateTimeInterface $date_res = null;

    #[ORM\Column]
    private ?float $prix_tot = null;

    #[ORM\ManyToOne(targetEntity: Materiel::class)]
    #[ORM\JoinColumn(nullable: false, name: "id", referencedColumnName: "id")]
    private ?Materiel $materiel = null;

    public function getIdRes(): ?int
    {
        return $this->id_res;
    }

    public function getNomClient(): ?string
    {
        return $this->nom_client;
    }

    public function setNomClient(string $nom_client): self
    {
        $this->nom_client = $nom_client;

        return $this;
    }

    public function getQteRes(): ?int
    {
        return $this->qte_res;
    }

    public function setQteRes(int $qte_res): self
    {
        $this->qte_res = $qte_res;

        return $this;
    }

    public function getDateRes(): ?\DateTimeInterface
    {
        return $this->date_res;
    }

    public function setDateRes(\DateTimeInterface $date_res): self
    {
        $this->date_res = $date_res;

        return $this;
    }

    public function getPrixTot(): ?float
    {
        return $this->prix_tot;
    }

    public function setPrixTot(float $prix_tot): self
    {
        $this->prix_tot = $prix_tot;

        return $this;
    }

    public function getMateriel(): ?Materiel
    {
        return $this->materiel;
    }

    public function setMateriel(?Materiel $materiel): self
    {
        $this->materiel = $materiel;

        return $this;
    }
}
