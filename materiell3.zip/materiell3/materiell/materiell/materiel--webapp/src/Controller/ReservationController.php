<?php

namespace App\Controller;

use App\Entity\Reservation;
use App\Entity\Materiel;
use App\Form\ReservationType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ReservationController extends AbstractController
{
    #[Route('/reservation/new/{materielId}', name: 'app_reservation_new')]
    public function new(Request $request, EntityManagerInterface $em, $materielId): Response
    {
        // Récupération du Materiel via l'ID
        $materiel = $em->getRepository(Materiel::class)->find($materielId);

        // Si le Materiel n'existe pas, lancer une exception 404
        if (!$materiel) {
            throw $this->createNotFoundException('Le matériel demandé n\'existe pas.');
        }

        // Créer une nouvelle réservation
        $reservation = new Reservation();
        $reservation->setMateriel($materiel); // Lier la réservation au matériel trouvé

        // Créer le formulaire de réservation
        $form = $this->createForm(ReservationType::class, $reservation);

        // Traiter la requête
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // Sauvegarder la réservation dans la base de données
            $em->persist($reservation);
            $em->flush();

            // Rediriger vers la liste des réservations après création
            return $this->redirectToRoute('app_reservation_index');
        }

        return $this->render('reservation/new.html.twig', [
            'form' => $form->createView(),
            'materiel' => $materiel, // Passer le matériel à la vue
        ]);
    }
}
